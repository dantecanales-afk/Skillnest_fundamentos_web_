const loginBtn = document.getElementById('loginBtn');

loginBtn.onclick = function () {
  if (loginBtn.innerText === 'Iniciar sesión') {
    loginBtn.innerText = 'Cerrar sesión';
  } else {
    loginBtn.innerText = 'Iniciar sesión';
  }
};

function Ver() {
  alert('Procesando...' );
}

function agregarLike(boton) {
  let likesActuales = parseInt(boton.getAttribute('datos-like'));

  likesActuales = likesActuales + 1;

  boton.setAttribute('datos-like', likesActuales);

  const spanLikes = boton.querySelector('.contador-likes');
  spanLikes.innerText = likesActuales;
}